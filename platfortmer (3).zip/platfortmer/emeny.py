from pygame import*



from GameSprite import GameSprite


class Enemy(GameSprite):
    direction = "Right"

    def update(self, screen):
        if self.direction == "Right":
            self.rect.x += self.speed
        if self.direction == "Left":
            self.rect.x -= self.speed

        if self.rect.x <= 450:
            self.direction = "Right"
        if self.rect.x >= 620:
            self.direction = "Left"

        super().update(screen)

enemy_left = [
    image.load('green_enemy_1-removebg-preview.png'),
    image.load('green_enemy_2-removebg-preview.png'),
    image.load('green_enemy_3-removebg-preview.png'),
    image.load('green_enemy_4-removebg-preview.png'),
    image.load('green_enemy_5-removebg-preview.png'),
    image.load('green_enemy_6-removebg-preview.png')
]
enemy_right = [
    image.load('green_enemy_1_коп-removebg-preview.png'),
    image.load('green_enemy_2_коп-removebg-preview.png'),
    image.load('green_enemy_3_коп-removebg-preview.png'),
    image.load('green_enemy_4_коп-removebg-preview.png'),
    image.load('green_enemy_5_коп-removebg-preview.png'),
    image.load('green_enemy_6_коп-removebg-preview.png'),

]

def animation(self, screen):
    # Если персонаж не двигается
    if not self.left and not self.right:
        # Показываем статичную картинку стоящего персонажа
        screen.blit(self.image, (self.rect.x, self.rect.y))
    elif self.left:
        # Анимация бега влево
        screen.blit(enemy_left[self.count // 10], (self.rect.x, self.rect.y))
        self.count += 1
    elif self.right:
        # Анимация бега вправо
        screen.blit(enemy_right[self.count // 10], (self.rect.x, self.rect.y))
        self.count += 1

    # Чтобы анимация работала корректно
    if self.count + 1 >= len(enemy_left) * 10:
        self.count = 0
