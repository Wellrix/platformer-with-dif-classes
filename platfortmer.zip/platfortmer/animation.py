from pygame import*

from PIL import Image
from pygame import image as pg_image, transform

def load_gif_frames(filename, size=(100, 100)):
    pil_gif = Image.open(filename)
    frames = []
    try:
        while True:
            pil_gif.seek(pil_gif.tell())
            frame = pil_gif.convert('RGBA')
            mode = frame.mode
            size_frame = frame.size
            data = frame.tobytes()
            py_image = pg_image.fromstring(data, size_frame, mode)
            py_image = transform.scale(py_image, size)
            frames.append(py_image)
            pil_gif.seek(pil_gif.tell() + 1)
    except EOFError:
        pass
    return frames
run_gif = load_gif_frames("__Run.gif", size=(150, 150))