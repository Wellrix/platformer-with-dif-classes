from pydoc_data.topics import topics

from pygame import*

walk_left = [
    image.load('pngwing.com_1___копия-removebg-preview.png'),
    image.load('pngwing.com_2___копия-removebg-preview.png'),
    image.load('pngwing.com_3___копия-removebg-preview.png'),
    image.load('pngwing.com_4___копия-removebg-preview.png'),
    image.load('pngwing.com_5___копия-removebg-preview.png'),
    image.load('pngwing.com_6___копия-removebg-preview.png'),
    image.load('pngwing.com_7___копия-removebg-preview.png'),
    image.load('pngwing.com_8___копия-removebg-preview.png')
]
walk_right = [
    image.load('pngwing.com_1-removebg-preview.png'),
    image.load('pngwing.com_2-removebg-preview.png'),
    image.load('pngwing.com_3-removebg-preview.png'),
    image.load('pngwing.com_4-removebg-preview.png'),
    image.load('pngwing.com_5-removebg-preview.png'),
    image.load('pngwing.com_6-removebg-preview.png'),
    image.load('pngwing.com_7-removebg-preview.png'),
    image.load('pngwing.com_8-removebg-preview.png'),
]
class GameSprite(sprite.Sprite):
    def __init__(self, filename, x, y, w, h, speed):
        super().__init__()
        self.image = transform.scale(image.load(filename), (w, h))
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed
        self.count = 0
        self.left = False
        self.right = False


    def update(self, screen):
        # Перерисовываем спрайт игрока
        screen.blit(self.image, (self.rect.x, self.rect.y))

    def animation(self, screen):
        # Если персонаж не двигается
        if not self.left and not self.right:
            # Показываем статичную картинку стоящего персонажа
            screen.blit(self.image, (self.rect.x, self.rect.y))
        elif self.left:
            # Анимация бега влево
            screen.blit(walk_left[self.count // 10], (self.rect.x, self.rect.y))
            self.count += 1
        elif self.right:
            # Анимация бега вправо
            screen.blit(walk_right[self.count // 10], (self.rect.x, self.rect.y))
            self.count += 1
        # Чтобы анимация работала корректно
        if self.count + 1 >= len(walk_left) * 10:
            self.count = 0

class Sprite(sprite.Sprite):
    def __init__(self, position, surface, group):
        super().__init__(group)
        self. image = surface
        self.rect = self.image.get_rect(topleft = position)
