from pygame import*
from GameSprite import Sprite
from pytmx import*


class Level:
    def __init__(self, level_map):
        self.screen = display.get_surface()
        self.all_sprites = sprite.Group()

        self.setup(level_map)

    def setup(self,level_map):
        for x,y,surf in level_map.get_layer_by_name('terrain').tiles():
            Sprite((x * 32, y * 32), surf, self.all_sprites)
            print(surf)


    def run(self):
        self.all_sprites.update()
        self.screen.fill("black")
        self.all_sprites.draw(self.screen)
